package com.example.interviewdemoproject.Services;

import com.example.interviewdemoproject.Dtos.AccountDto;

public interface AccountService {
    AccountDto createAccount(AccountDto accountDto);
}
