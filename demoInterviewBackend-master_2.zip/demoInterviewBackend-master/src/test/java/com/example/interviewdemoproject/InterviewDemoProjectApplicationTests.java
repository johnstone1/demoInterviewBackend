package com.example.interviewdemoproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewDemoProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
